package com.src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Retrievedata {

	public static void main(String[] args) {
		
		String url="jdbc:mysql://localhost:3306/practice_db";
		String user="root";
		String password="pavani";
		
		try(Connection con=DriverManager.getConnection(url,user,password)) {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Statement st=con.createStatement();
			
			ResultSet rs=st.executeQuery("select * from accountinfo");
			
			while(rs.next())
			{
				System.out.println(rs.getInt("accountid")+"| "+rs.getInt("customerid")+"| "+rs.getString("accounttype")+"| "+rs.getFloat("accountbalance")+"| "+rs.getString("accountopendate")+"| "+rs.getString("accountstatus"));
			}
			
			
		}
		catch(ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

	}

}
